package com.flow.NaverMovie_KJS;

import java.util.ArrayList;

public class MovieList {
    ArrayList<Movie> items = new ArrayList<Movie>();
}